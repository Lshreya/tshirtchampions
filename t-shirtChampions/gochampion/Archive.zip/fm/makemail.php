<html>
<body>
<form id='message' action='sendmail.php' method='post'>


<!-- Set Security Key -->
	<input type='text' name='key' value='Champion2016fmHUB' />



<!-- Set recipient -->
	<input type='text' name='to' value='

	paul@gochampion.net

	' />
	
<!-- Set subject -->
	<input type='text' name='subject' value='
	
	sent!
	
	' />

<!-- Set message -->
	<input type='text' name='body' value='

	<br><strong>CURRENT</strong><br><br><em>An email was sent!</em>

	'/>

<p>hi</p>

</form>
<script>document.getElementById('message').submit();</script>
</body>
</html>













