
<div id="b_topofpage">
<a href="#topofpage"><img src="images/b_topofpage.png" width="70" height="35" alt="Top of Page button"/></a>
</div>
<div id="b_secure">
<span id="siteseal"><script type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=AZQ36OATLH6LuCTx8nkkaifPkw6x5mFCZIZmF3tcGRqmtJfcLThRP7Tns"></script></span>
</div>

<div id="b_facebook">
<a href="http://www.facebook.com/ChampionAwards"><img src="images/b_facebook.jpg" width="220" height="25" alt="Facebook button"/></a>
</div>
<g:plusone></g:plusone>

<!--  Place this tag after the last plusone tag -->
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>



<p class="darkertext_shift"> 
Champion Awards and Apparel, Inc.  : :  3649 Winplace Road  : :  Memphis, TN 38118  : :  (901) 365-4830 Phone  : :  (901) 365-2796 Fax<br/><br/>

gochampion.net  : :  &copy; 2010-2012 All rights reserved</p>



<script src=https://seal.verisign.com/getseal?host_name=www.gochampion.net&size=L&use_flash=YES&use_transparent=YES&lang=en></script>