<style type="text/css">
<!--
#heading_contact .darkertext-heading {
	font-size: 14px;
}
-->
</style>

<a href="http://www.tshirtchampions.com"  alt="Click to switch to T-Shirt Champions."
style="
	display:block;
	position:absolute;
	top: -80px;
	left:275px;
	width:180px;
	height:75px;
	z-index:1000;
"
></a>

	<div id="heading_wreath">
	
	</div>
	
	
	<div id="heading_help">
				
				<ul id="button_contact"> 
				<li><a href="contact.php" class="contact"><span></span></a></li> 
				</ul>
				
	</div>
	
	<div id="heading_fb">
		<a class="opacitylink" href="http://www.facebook.com/ChampionAwards"><img src="images/fb_icon.png" width="28" height="28" alt=""/></a>
        

	</div>
	
	<div id="heading_contact">

	
	</div>
	
	<div id="button_subscribe"> 
	<a href="subscribe.php"><img src="images/b_subscribe.jpg" width="81" height="50" alt=""/></a>
	</div>