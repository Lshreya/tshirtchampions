

				<ul id="quotes">					
				
					<li>
						<a href="testimonials.php"><img src="quote/quote_uofm.jpg" alt="UofM quote" /></a>
					</li>
					<li>
						<a href="testimonials.php"><img src="quote/quote_shelbyfarms.jpg" alt="Shelby Farms quote" /></a>
					</li>
					<li>
						<a href="testimonials.php"><img src="quote/quote_olympics.jpg" alt="Special Olympics quote" /></a>
					</li>
					<li>
						<a href="testimonials.php"><img src="quote/quote_gameday.jpg" alt="Gameday quote" /></a>
					</li>
					<li>
						<a href="testimonials.php"><img src="quote/quote_source.jpg" alt="Source quote" /></a>
					</li>
					
					<li>
						<a href="testimonials.php"><img src="quote/quote_sysco.jpg" alt="Sysco quote" /></a>
					</li>		
				</ul>