
<a href="tour.php"><img src="images/b_tourfacility.jpg" width="240" height="67" alt="Tour our Facility"/></a>

<a href="mikesblog.php"><img src="images/b_mikesblog.jpg" width="188" height="67" alt="Mike's Blog: Grown up Kid"/></a>
	