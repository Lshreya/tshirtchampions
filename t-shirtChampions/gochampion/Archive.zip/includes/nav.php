				<ul id="menu"> 
				<li><a href="index.php" class="home"><span></span></a></li> 
				<li><a href="graphics.php" class="graphics"><span></span></a></li> 
				<li><a href="embroidery.php" class="embroidery"><span></span></a></li> 
				<li><a href="awards.php" class="awards"><span></span></a></li> 
				<li><a href="screenprinting.php" class="screenprinting"><span></span></a></li> 
				<li><a href="estores.php" class="estores"><span></span></a></li> 
				<li><a href="about.php" class="about"><span></span></a></li> 
				</ul>	
				
				<div id="position_sub-navmenu">
				<img src="images/champion_sub-navsprite.jpg" width="490" height="29" alt="Main Navigation sub" usemap="#sub-navmenu"/>
				<map name="sub-navmenu" id="sub-navmenu">
  				<area shape="rect" coords="0,0,146,29" href="custservice.php" alt="Customer Service" />
  				<area shape="rect" coords="147,0,321,29" href="promproducts.php" alt="Promotional Products" />
  				<area shape="rect" coords="322,0,490,29" href="eventmerch.php" alt="Event Merchandising" />
				</map>
				</div>
				
				
				<div id="salestag">
				<img src="images/salestag.png" width="73" height="47" alt="Sales tag"/>
				</div>
				
				
				

