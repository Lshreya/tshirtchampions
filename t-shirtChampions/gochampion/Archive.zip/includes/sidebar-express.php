<img src="images/b_expmain.png" width="275" height="150" alt="Express Services" usemap="#expmain" />

<map name="expmain" id="#expmain">
  <area shape="rectangle" coords="10,40,130,90" href="express_cap.php" alt="CapEXPRESS" />
  <area shape="rectangle" coords="10,95,130,150" href="express_tshirt.php" alt="T-ShirtEXPRESS" />
  <area shape="rectangle" coords="145,40,260,90" href="express_awards.php" alt="AwardsEXPRESS" />
  <area shape="rectangle" coords="145,95,260,150" href="http://www.poloxpress.net" target="_blank" alt="Polo Express" />
</map>