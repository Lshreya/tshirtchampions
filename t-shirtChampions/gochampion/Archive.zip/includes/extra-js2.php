<script type="text/javascript">
	   $(document).ready(
				function(){
					$('ul#quotes').innerfade({
						speed: 1000,
						timeout: 5000,
						type: 'sequence',
						containerheight: '80px'
					});
			});
  	

</script>	
  	
  	
  	
