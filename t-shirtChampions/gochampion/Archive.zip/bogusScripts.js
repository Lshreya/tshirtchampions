$(document).ready(function(){

$("nav.header-nav ul").prepend('<li class="header-nav-home"><a href="http://gochampion.net">Home</a></li>');


});
