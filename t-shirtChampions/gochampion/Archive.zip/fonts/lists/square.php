<li id="pwFontCell_3433_0" onclick="pwFontManager.toggleFont(&#39;3433&#39;);" ondblclick="pwFontManager.toggleFont(&#39;3433&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(1).gif" border="0">
<br><span>
Abel</span><br><br>
</li>
<li id="pwFontCell_342_0" onclick="pwFontManager.toggleFont(&#39;342&#39;);" ondblclick="pwFontManager.toggleFont(&#39;342&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(49).gif" border="0">
<br><span>
Archery</span><br><br>
</li>
<li id="pwFontCell_3443_0" onclick="pwFontManager.toggleFont(&#39;3443&#39;);" ondblclick="pwFontManager.toggleFont(&#39;3443&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(54).gif" border="0">
<br><span>
Armata</span><br><br>
</li>
<li id="pwFontCell_4548_0" onclick="pwFontManager.toggleFont(&#39;4548&#39;);" ondblclick="pwFontManager.toggleFont(&#39;4548&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(294).gif" border="0">
<br><span>
Iceberg</span><br><br>
</li>
<li id="pwFontCell_3468_0" onclick="pwFontManager.toggleFont(&#39;3468&#39;);" ondblclick="pwFontManager.toggleFont(&#39;3468&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(467).gif" border="0">
<br><span>
Syncopate</span><br><br>
</li>
