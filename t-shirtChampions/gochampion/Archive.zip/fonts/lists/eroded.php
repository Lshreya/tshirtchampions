<li id="pwFontCell_652_0" onclick="pwFontManager.toggleFont(&#39;652&#39;);" ondblclick="pwFontManager.toggleFont(&#39;652&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(103).gif" border="0">
<br><span>
Carbontype</span><br><br>
</li>
<li id="pwFontCell_4308_0" onclick="pwFontManager.toggleFont(&#39;4308&#39;);" ondblclick="pwFontManager.toggleFont(&#39;4308&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(228).gif" border="0">
<br><span>
Finger Paint</span><br><br>
</li>
<li id="pwFontCell_4353_0" onclick="pwFontManager.toggleFont(&#39;4353&#39;);" ondblclick="pwFontManager.toggleFont(&#39;4353&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(241).gif" border="0">
<br><span>
Fredericka the Great</span><br><br>
</li>
<li id="pwFontCell_4553_0" onclick="pwFontManager.toggleFont(&#39;4553&#39;);" ondblclick="pwFontManager.toggleFont(&#39;4553&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(295).gif" border="0">
<br><span>
IM FELL DW Pica</span><br><br>
</li>
<li id="pwFontCell_1622_0" onclick="pwFontManager.toggleFont(&#39;1622&#39;);" ondblclick="pwFontManager.toggleFont(&#39;1622&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(412).gif" border="0">
<br><span>
Oldcopperfield</span><br><br>
</li>
<li id="pwFontCell_1802_0" onclick="pwFontManager.toggleFont(&#39;1802&#39;);" ondblclick="pwFontManager.toggleFont(&#39;1802&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(437).gif" border="0">
<br><span>
Repent</span><br><br>
</li>
<li id="pwFontCell_5397_0" onclick="pwFontManager.toggleFont(&#39;5397&#39;);" ondblclick="pwFontManager.toggleFont(&#39;5397&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(462).gif" border="0">
<br><span>
Spastic</span><br><br>
</li>
