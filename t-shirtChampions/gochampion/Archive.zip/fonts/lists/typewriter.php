<li id="pwFontCell_302_0" onclick="pwFontManager.toggleFont(&#39;302&#39;);" ondblclick="pwFontManager.toggleFont(&#39;302&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(60).gif" border="0">
<br><span>
Atwriter</span><br><br>
</li>
<li id="pwFontCell_3608_0" onclick="pwFontManager.toggleFont(&#39;3608&#39;);" ondblclick="pwFontManager.toggleFont(&#39;3608&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(147).gif" border="0">
<br><span>
Copse</span><br><br>
</li>
<li id="pwFontCell_4068_0" onclick="pwFontManager.toggleFont(&#39;4068&#39;);" ondblclick="pwFontManager.toggleFont(&#39;4068&#39;); pwFontManager.selectCurrentFont();" ;="" onmousemove="pwSelFontMm(this);" onmouseout="pwSelFontMo(this);">
<br><img src="font_list_resources2_files/sample(166).gif" border="0">
<br><span>
Cutive</span><br><br>
</li>
