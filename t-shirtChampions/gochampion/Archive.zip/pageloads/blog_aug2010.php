
    <div id="contentload2"> 
		<p class="darkertext">
		
		
		
		<i>Power of One (Part VII)</i><br/><br/>
<strong>Power of One-No Regret</strong><br/><br/>
August 2010<br/><br/><br/>

 The last article I wrote was supposed to be the last "Power of One" in a series. I have heard from hundreds of folks about these simple life reminders that I felt compelled to continue. So here goes......
<br/><br/>
    I'm not the easiest person to live with. I know this because my wife or my conscience, as I affectionately refer to her, reminds me at least once a week. Like a lot of us (especially men) I get self absorbed, feel sorry for myself, don't keep a pleasant attitude and I could go on and on and on but I won't. I make this point because every so often I wake up and realize I'm the luckiest person in the world.    
<br/><br/>
Just last month, I got to spend eleven days with my two sons and several old friends on an "all guys" fishing and golfing trip at our house at Heber Springs. And guess what?  This is the 5th year in a row I've done it. My wife even encourages it. Yes, I know what you're thinking, she gets rid of me for eleven days. But when I came back she went to Florida with our sons. The surprising thing, is most folks think this is crazy. But we go on another vacation, just the two of us each year. We also go somewhere with our boys as a family. So life is good.    
<br/><br/>
It gets better. I have a single friend who has made an art out of going to the Caribbean Islands. I think he has been to all of them more than once. I have always wanted to go but not dare ask my wife. Last month, he was going to the Mexican Riviera for six days and I casually mentioned to my wife that I could stay free. In a joking manner, I asked, "If we had any free miles?" She promptly looked in her trusty laptop at the kitchen table. I was booked in thirty minutes. Can you believe that? We had a fantastic lazy time on the beach at 82° while Memphis was sweltering at over 100°.   
<br/><br/>
It gets even better than that. When I got back home the Wooddale High School Class of 1975 Reunion was held the next week. We had not had one in ten years. Three lovely ladies did all the work and all we had to do was show up and party. You would be amazed at how many did not show.  The people that came had a blast and asked "Why don't we do this more often?"I tell you all this because during the month of July I lost nine people I knew. Some very well, some not so well. But I would give anything to have spoken to them at least once more. Its that time in my life, this will happen again and again as the years go by.
<br/><br/>
Jerry Rice upon his recent induction into the National Football Association Hall of Fame said, "But if I have a single regret about my career standing here today, it's that I never took the time to enjoy it."
<br/><br/>
So I pledge to "do it now!" Especially when it comes to family and friends. Call your mom and/or your dad each day. Remember, some people wish they still could. Tell your kids you love them each day. Call an old friend and have lunch. Treat your spouse just a little bit better or in my case a lot better. Remember; In life the only thing worse than "No Hope" is Regret. Stop depending on tomorrow; pledge to "Have no Regret, Do it Now!"

<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now Here's the Pitch:</strong> Save the date! <strong><i>Friday, October 15th</i></strong> is our 40th Anniversary Celebration and Customer Appreciation day. Invitations to go out soon.  			
    				
			
			
		</p>
    </div>