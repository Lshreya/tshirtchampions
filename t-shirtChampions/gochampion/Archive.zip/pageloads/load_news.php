
    <div id="contentload"> 
		<br/><br/>
		<p class="darkertext">


<img src="images/pageheader-mini.jpg" width="490" height="20" alt="News"/>

    <div id="40th"></div>
    				<p class="darkertext">
    				<strong>Champion 40th Anniversary Celebration</strong><br/><br/>
    				<i>October 15, 2010</i><br/>
    				@ <a href="http://maps.google.com/maps?oe=utf-8&ie=UTF8&q=champion+awards&fb=1&gl=us&hq=champion+awards&hnear=Memphis,+TN&hl=en&view=map&f=d&daddr=3649+Winplace+Rd,+Memphis,+TN+38118-5512&geocode=CWqAMMmspsAyFZfOFgIdF2ak-iE_j7nJ2lXyUw&ved=0CGkQ_wY&ei=TteYTJXeBI-GzgTQ6JzRBg&z=16">Champion Awards and Apparel</a><br/>
    				
    				<br/><br/>
    				<img class="align-right" src="images/slide_40th-box.jpg" width="180" height="125" alt="Pastner Classic"/>
    					Champion is having a party and you're invited! We are celebrating our 40th Anniversary. Join us for tours and fun...
<br/><br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Tours of the Plant from 10-4 (See how your Tees, Polos & Awards are made)<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Lunch - Hamburgers and Hot Dogs from 11-1pm<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Goodie Bags, Samples and Door Prizes All Day<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Vendor Showcase of New 2011 Apparel, Awards and Promotional Product Lines<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Selling $5.00 Memphis Basketball Tees to raise money for CASA for abused and neglected children.
<br/><br/>
When: Friday, October 15th – 10am to 4pm<br/>
Where: Champion Awards and Apparel – 3649 Winplace Rd – Memphis TN 38118<br/>
Why: To have fun and help us raise money for abused and neglected children<br/><br/>

Please RSVP by October 11th if coming for lunch.<br/><br/>
    				
    				
    				<a href="http://www.facebook.com/home.php?#!/event.php?eid=155482001136320">RSVP on Facebook</a>
    				</p>
    				
    				
    				
    				
    				<br/><img src="images/pageheader-mini.jpg" width="490" height="20" alt="News"/> 
    				
    				
    				
    				
    				
    				<div id="golf"></div>
    				<p class="darkertext">
    				<strong>The 2nd Annual Coach Josh Pastner Golf Classic</strong><br/><br/>
    				<i>October 11, 2010</i><br/>
    				Germantown Country Club<br/>
    				
    				
    				<br/><br/>
    				<img class="align-right" src="images/news_pastnerclassic.jpg" width="170" height="400" alt="Pastner Classic"/> 
    				Come join us for the 2nd Annual Josh Pastner Golf Classic. Support our team and our great coach! Download the <a href="news/10MemphisReboundersBrochure.pdf">brochure</a> for more information. Four man scramble format - four flights.
<br/><br/> <br/> 
Tournament Sponsorship Packages:<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Tiger Sponsor - $5,000<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Blue Sponsor - $2,500<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Playing Sponsor - $1,000<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Putting Contest Sponsor - $1,000<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Hole Sponsors - $250<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Longest Drive Contest Sponsor - $250<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Closest to the Hole Sponsor - $250<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Playing Team - $800<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Individual Player - $250<br/>
<img src="images/mini-arrow.jpg" width="10" height="15" alt="mini arrow"/>Additional Putts in contest - $5<br/>

<br/><br/><br/><br/><br/>
<a href="http://bit.ly/auOmPH">Register Online</a> or <a href="news/10MemphisReboundersBrochure.pdf">by Mail</a><br/><br/>


</p>

<br/>


    	</p>
    </div>