
    <div id="contentload2"> 
		<p class="darkertext">	
			<i>Power of One (Part V)</i><br/><br/>
<strong>One Man’s Will To Change</strong><br/><br/>
May 2010<br/><br/><br/>
     Over the past four months I have written a series of Power of Ones; Idea, Greatness, Presentation, and Customers. This month I will address the Power of One Man’s will to change and succeed.
 <br/><br/>
     After forty years in business, I have seen literally thousands of men and women come thru my doors for employment. I have written before that Champion Awards and Apparel was not always the easiest place to work much less thrive. In the 1980’s early 90’s we were authorized printers for Nike, Reebok, VF Imagewar, Hanes, Disney and a host of others. We ran over 50,000 t-shirts and three shifts daily. Trouble was, we were a glorified sweatshop and didn’t make any money. People were just not happy.
<br/><br/>
     Fast forward to 2007. We had a one-shift team environment. Our average team member has been with us over ten years now. Quite frankly, this is our greatest achievement along with over one thousand happy customers.
<br/><br/>
     I tell you all this because one day three years ago we hired Marlo. He was hired as a part time janitor. He just looked awful. You know, with a slumped over walk like a gang banger, with low pants, tank tops, dreadlocks, and tattoo’s from head to toe. I asked, “Where in the hell did this guy come from?” To my surprise, I was told he had a glowing reference from his pastor. You see, Marlo was indeed a gang banger that was on the right end of a shootout (If there is such a thing). Still he served over 8 years in prison. I heard these “rumors” and I had to get to the bottom of this. It was all true even down to the teardrop tattoo under his eye. But he had turned his life over to his higher power and he was trying to change.
<br/><br/>
     Fast-forward three more years to 2010. Marlo Starks is on his way to being Employee of the Year. Yes he still is the best cleaning person
we have, but now he is our Warehouse, and Shipping and Receiving Manager. At Champion, that means he does it all! Some days he handles
over 150 shipments alone. He has become proficient on the computer as well. He has received a ton of help, mainly from his Director of
Operations, Lee Raney. Yes, Marlo has made some mistakes along the way. But, he never stops trying his very best everyday. Most
importantly, he walks and talks like a man should. He looks you in your eyes and he smiles. He also moved  his mother and himself to a safer
place to live. Also, he gives his testimony to church youth groups when ever he can. I am proud to know Marlo Starks. I am proud he is a
member of my team.
<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now here’s the pitch:</strong> There are more Marlo’s out there! Champion now has 4 more potential Marlo’s in training. We know of other small
businesses in this city that hire former offenders. But many more jobs are needed for these men and women to make it “on the outside.”
It takes one on one help and someone who really cares to make a difference in someone’s life. Give a former offender a break today.
			
    				
			
			
			</p>
    </div>