<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mike's Blog: Business Advice from a Grown Up Kid | gochampion.net</title>

<!-- META -->
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
	<meta name="robots" content="index, follow" /> 
	<meta name="description" content="Mike Bowen imparts his thoughts, stories and experience from more than 30 years in screen printing and awards." /> 
	<meta name="keywords" content="champion awards, business advice, apparel merchant, business blog, grown up kid" /> 
	<meta name="author" content="Champion Awards" /> 
	<meta name="copyright" content="Copyright July 2010" /> 

<!-- CSS --> 
		<link rel="stylesheet" href="masterstyles.css" type="text/css" media="screen" />
		<!--[if lt IE 7.]><style type="text/css">@import url("masterstylesIE6.css");</style><![endif]-->

<!-- SITE ICONS -->
	<link rel="shortcut icon" href="http://www.gochampion.net/images/favicon.ico" /> 
	<link rel="apple-touch-icon" href="images/appleicon.png" /> 
 
	
<!-- GLOBAL JAVASCRIPT --> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery-masterscripts.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			
			$("a#stdzoom").fancybox({
				'titleShow'		: true,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic',
				'overlayOpacity' 	: 0.8,
				'overlayColor' 		: '#666',
				'titlePosition'	: 'over',
				'hideOnContentClick' : 'true'
			});
			
		});
	</script>



	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17525979-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	</script>
	
	<!-- CONDITIONAL JAVASCRIPT --> 
	<!--[if lt IE 7.]><script defer type="text/javascript" src="js/pngfix.js"></script><![endif]-->



</head>

<body>

<div id="topofpage"></div>


<div id="header">
</div>	      

<div id="container">


	<?php include("includes/header.php"); ?>

	
	
  
     <div id="content"> 



			<div id="position_navmenu">
			
				<?php include("includes/nav.php"); ?>
				
			</div>


			<div id="position_leftcol"> 
			
			
			<img src="images/pageheading_mikesblog.jpg" width="490" height="80" alt="Mike's Blog: Grown up Kid"/> 
			
			
			

   
    <div id="contentload2" class="editable" title="">
      <p class="darkertext"><strong>Another Good Deed</strong></p>
      <p>
      <br />July 2013</p>
      <div>
  <div>
<p>This year marks our 44th year of business at Champion. Being in the Tshirt, Trophy, and Promotions business has allowed us the opportunity to work with thousands of causes over the years.<br />
One result of that being more than 500 requests for free or discounted products and services received annually. I consider it a privilege to be asked, but as a small business, we simply must pick and choose our causes, lest we end up ourselves on the other side of this equation!</p>
<p>Recently we received a call from a Vacation Bible School Director who had bitten off more than he could chew. He wanted 18 of his students to learn how to design, set up, and print 600 tshirts in less than 4 days! He wanted to do this at the church with an amateur set of supplies, tools and no dryer. Needless to say, he needed professional help, and he needed it for free!</p>
<p>For those readers who are not screen printing professionals, allow me to put this request into perspective. It takes at least 2 days for our team, of 4-5 professionals, to accomplish of an order this size from start to finish. Now, this was a Church with sufficient means to hire a teacher. It also happens that this request came right in the middle of our very busiest season. I asked the Director if he was crazy? He did admit to a little bit of over zealousness. My first impulse was to politely decline, but then I do love a challenge. The real question then became, who amongst my team&nbsp;could teach screen-printing to ten and eleven year olds, and still maintain his, or her, hectic schedule at Champion?</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;I explained&nbsp;this predicament&nbsp;to Brandon, our VP of Customer Care. Well, really I &quot;dumped&quot; it on him! Our world famous illustrator, Mitch Foust, overheard our conversation, and out of the blue said, &ldquo;I can do this!&rdquo; Aside from creating award winning designs for our clients, Mitch is also a published Graphic Illustrator of &quot;David, The Illustrated Novel:&nbsp;volumes 1 and 2. Mitch spent 5 days facing down this particular Goliath, teaching children the rather complex art of design and screen-printing. On Friday morning, he counted the finished tees and discovered they were about 75 pieces short. Mitch brought the screens they had created back to Champion where we printed the shortage and returned them to the church on Friday afternoon. This was just in time&nbsp;to distribute fresh, new tees to over 600 children!<br />
  For a professional like Mitch, it was all about the love of art and about sharing that love with the next generation. Simply put, well done! I am so proud to have people like Mitch on the Champion team. People who understand that serving our community is not a chore, nor a gimmick, but rather an obligation, and an opportunity to give something back!</p>
<p>&quot;How far that little candle throws its beams! Show signs a good deed in a naughty world! &quot; William Shakespeare.</p>
  </div>
<p class="darkertext"><br /> 
  <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Think it's hot outside? </strong>Take a look at the deals we've got for you!...<a href="http://www.gochampion.net/images/13_Blast_Embroidery3b.jpg" target="_blank">Click Here</a>.</p>
    </div>


					
				<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    				
    				
    				
    				
    			
    			
    			
    			 
    			 <h3>Archives</h3>
				<img src="images/heading_sidebar.png" width="275" height="8" alt="Archives"/>
				<div class="darkertext">
    			     			 <a href="mikesblog.php">July 2013 - The Stupid Tax</a>
    			 <ul id="navload">
<li><a href="pageloads/blog_JulyA2013.php">July 2013 - Another Good Deed</a></li> 
<li><a href="pageloads/blog_JuneB2013.php">June 2013 - Teamwork & Good Deeds</a></li> 
<li><a href="pageloads/blog_JuneA2013.php">June 2013 - Resignation</a></li> 
<li><a href="pageloads/blog_MayB2013.php">May2013 - Memphis Rocks II</a></li> 
<li><a href="pageloads/blog_MayA2013.php">May2013 - More Good News</a></li> 
<li><a href="pageloads/blog_aprB2013.php">April 2013 - A Little Good News</a></li>                          
<li><a href="pageloads/blog_apr2013.php">April 2013 - Teach! Don't Bully</a></li>
<li><a href="pageloads/blog_mar2013.php">March 2013 - Remember The Romance</a></li>
<li><a href="pageloads/blog_feb2013b.php">February 2013 - So God Made an Entrepreneur</a></li>
<li><a href="pageloads/blog_feb2013a.php">February 2013 - Reunion and Redemption</a></li>
<li><a href="pageloads/blog_Jan2013b.php">January 2013 - WILL Power!</a></li>
<li><a href="pageloads/blog_Jan2013a.php">January 2013 - Fatigue Makes Cowards Of Us All</a></li>
<li><a href="pageloads/blog_dec2012.php">December 2012 - The Bucket List</a></li>
<li><a href="pageloads/blog_dec.php">December 2012 - From the State Orphanage to the State Capitol</a></li>
<li><a href="pageloads/blog_nov2012.php">November 2012 - The Elections are not over!</a></li>
<li><a href="pageloads/blog_octB2012">October 2012 - Friends of a Brave Man!</a></li>
<li><a href="pageloads/blog_2oct12.php">October 2012 - The Retirement Myth</a></li>
<li><a href="pageloads/blog_sept20122.php">September 2012 - Help Suzie Help Abused Children, and Get FREE Stuff!</a></li>
<li><a href="pageloads/blog_sept20121.php">September 2012 - Memphis Rocks!</a></li>
<li><a href="pageloads/blog_sept2012.php">August 2012 - Late Bloomers III: The Solution.</a></li>
<li><a href="pageloads/blog_aug2012.php">August 2012 - Late Bloomers II.</a></li>
<li><a href="pageloads/blog_july2012.php">July 2012 - Late Bloomers.</a></li>
<li><a href="pageloads/blog_june2012.php">June 2012 - Loss in a Leader.</a></li>
<li><a href="pageloads/blog_may2012.php">May 2012 - Leaders in the Making.</a></li>
<li><a href="pageloads/blog_apr12012.php">April 2012 - Here is to the Crazy One's</a></li>
<li><a href="pageloads/blog_apr2012.php">April 2012 - Fifteen Minutes of Terror!</a></li>
<li><a href="pageloads/blog_mar1_2012.php">March 2012 - Planning is Fun, yea right</a></li>
<li><a href="pageloads/blog_mar2012.php">March 2012 - A Lesson learned in the loss of a pet.</a></li>
<li><a href="pageloads/blog_feb2012.php">February 2012 - Humility, good for the Soul and Business.</a></li>
<li><a href="pageloads/blog_jan2012.php">January 2012 - Goal setting, not for the weak of heart.</a></li>
<li><a href="pageloads/blog_dec2011.php">December 2011 - Life is a struggle, but we still LIVE.</a></li>
<li><a href="pageloads/blog_oct2011.php">October 2011 - Power of the T-Shirt</a></li>
<li><a href="pageloads/blog_aug2011.php">Aug 2011 - Buy Memphis Now!</a></li>
<li><a href="pageloads/blog_may12011.php">May 2011 - Children are our greatest asset.</a></li>
<li><a href="pageloads/blog_may2011.php">May 2011 - Dream, Believe and Achieve</a></li>
<li><a href="pageloads/blog_mar2011.php">Mar 2011 - Don't Let the Job Get in the Way of the Job</a></li>
<li><a href="pageloads/blog_feb2011.php">Feb 2011 - It's Time for an Attitude Adjustment</a></li>
<li><a href="pageloads/blog_jan2011.php">Jan 2011 - Start With Why</a></li>
<li><a href="pageloads/blog_dec2010.php">Dec 2010 - Power of Santa Claus</a></li>	
<li><a href="pageloads/blog_nov2010.php">Nov 2010 - Power of Giving Thanks</a></li>	
<li><a href="pageloads/blog_oct2010.php">Oct 2010 - Power of One-One Team</a></li>	
<li><a href="pageloads/blog_sep2010.php">Sep 2010 - Power of One-Volunteer</a></li>	
<li><a href="pageloads/blog_aug2010.php">Aug 2010 - Power of One-No Regret</a></li>		 
<li><a href="pageloads/blog_jul2010.php">Jul 2010 - Power of One-Women</a></li>
<li><a href="pageloads/blog_may2010.php">May 2010 - One Man's Will to Change</a></li>
<li><a href="pageloads/blog_apr2010.php">Apr 2010 - The Power of the Customer</a></li>
<li><a href="pageloads/blog_feb2010.php">Feb 2010 - The Power of Presentation</a></li>
<li><a href="pageloads/blog_jan2010.php">Jan 2010 - Dare to be Great</a></li>
    </ul></div>
    			
    			
    			
    			<h3>Contact</h3>
				<img src="images/heading_sidebar.png" width="275" height="8" alt="Contact"/>	
    			<p class="darkertext">	
				For comments on this months article or general questions for Mike Bowen, email him at <a href="mailto:mike@gochampion.net?Subject=GoChampion.net - BLOG">mike@gochampion.net</a>.
				
				<br/><br/>
				
				<a href="http://www.facebook.com/people/Mike-Bowen/1040078256"><img src="images/facebookicon-large.jpg" width="30" height="32" alt="Facebook Icon"/>	</a>
			
				
				</p>
				
				
				
			</div>




  	</div>   
 	 

	<div id="footer">

		<?php include("includes/footer.php"); ?>
	
	</div>
	
	
</div>


</body>
</html>