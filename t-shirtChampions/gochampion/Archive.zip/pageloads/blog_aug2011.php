
    <div id="contentload2"> 
		<p class="darkertext"><strong>Buy Memphis Now!</strong><br />
		  <br />
August 2011<br />
<br />
<br />
Its been two months since my last column. With so many people on vacation, me included, I took a break for the first time in two years. I can honestly say, I have missed writing to you. But most of all, I have missed hearing your feedback. On a personal note, in June, Suzie and I sold Tiger Gift Shop to Jeremy and Tonia Stinson. We did this to spend all our focus on growing Champion Awards and Apparel. Now to this months topic.<br />
<br />
<br />
The Lipscomb &amp; Pitts Breakfast Club is a group of more than sixty CEO's in non competitive industries. Champion is a new member. We meet monthly for business networking, speakers &amp; workshops to better our City thru business and philanthropy. When asked to join, I wondered &quot;Why does our forty-two year old company need to spend a lot of money to network&quot;? After all we network everyday. I also asked &quot;how are we going to get a return on our investment of Time &amp; Money.&quot;<br />
<br />
That's when Jeremy Parks, Director of Communications, showed me the commercial for the Power of the Dollar Campaign. You know the one, where Prominent business executives are passing a one dollar bill from one to the next. They tell you two simple facts that amazed me:<br />
<br />
The Economic Impact:<br />
<br />
For every dollar spent locally in Memphis, it becomes worth $1.70 to the economy. <br />
<br />
That for every million dollars spent in Memphis, eleven jobs are created locally!!<br />
<br />
<br />
Jeremy said &quot;that the Breakfast Club was committed to bringing businesses together to actually conduct business and philanthropy TOGETHER&quot;. What a unique idea! I have been involved with many organizations in our city in my thirty two year career. I can honestly say Champion has not only received new customers, but we have also received a return on our investment. The Lipscomb Pitts Breakfast Club offers a tremendous amount of business and education to our employees and customers. But the &quot;Power of the Dollar&quot; campaign really struck a nerve with me. As a small family owned company this is what it is all about. Kemmons Wilson, famed entrepreneur from Memphis, said &quot;Memphis is one of the hardest places in the world to do business. That if you can make it in Memphis, you can make it anywhere. &quot;I believe that wholeheartedly.<br />
<br />
The biggest companies in our city do a tremendous amount of business with out of town companies. There is an old saying in Memphis, &quot;An expert in Memphis is someone or some business from out of town.&quot; Think about this, since 2007, the Memphis Gross Domestic Product (GDP) has reduced every year by at least a full percentage point. That percentage point represents millions! The statistics show, that if we all improved our local spending by ten to twenty percent, our economy would at least improve that much.<br />
<br />
People ask me all the time, &quot;who are your biggest competitors?&quot; My response is always the same. It's ourselves&quot;. We as small business, don't have public relations departments or large sales forces. We must depend on our relationships, and the loyalty of our customers for quality products and service. Loyalty and relationship in our society is waning. We must learn to stick together as small business. <br />
<br />
So, just by spending our money with locally owned and operated companies first, (they may not always be the cheapest) we can increase revenue &amp; dramatically reduce taxes! I'm all in! We at Champion get killed every day by the out of town internet promotional product companies. We will not always be the cheapest, but we are one of the best Apparel Screenprinters &amp; Embroiderers in the world. We also design &amp; make a mean Award (Plaques, Crystal &amp; Trophies). In the near future we will be improving our online ordering capability. We are not going to lie down. We will continue to be a leader in our industry. <br />
<br />
If you want to reduce taxes and help Memphis Grow, keep dollars local!!<br />
</p>
		<p class="darkertext"><img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
  <strong>Now Here's the Pitch:</strong>Champion has designed a logo representing the power of the dollar.</p>
		<p class="darkertext">Contact mike@gochampion.net if you want to use this in your marketing. Completely free of charge.</p>
</div>


					
				<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>