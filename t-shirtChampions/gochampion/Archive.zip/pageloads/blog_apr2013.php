<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mike's Blog: Business Advice from a Grown Up Kid | gochampion.net</title>

<!-- META -->
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
	<meta name="robots" content="index, follow" /> 
	<meta name="description" content="Mike Bowen imparts his thoughts, stories and experience from more than 30 years in screen printing and awards." /> 
	<meta name="keywords" content="champion awards, business advice, apparel merchant, business blog, grown up kid" /> 
	<meta name="author" content="Champion Awards" /> 
	<meta name="copyright" content="Copyright July 2010" /> 

<!-- CSS --> 
		<link rel="stylesheet" href="masterstyles.css" type="text/css" media="screen" />
		<!--[if lt IE 7.]><style type="text/css">@import url("masterstylesIE6.css");</style><![endif]-->

<!-- SITE ICONS -->
	<link rel="shortcut icon" href="http://www.gochampion.net/images/favicon.ico" /> 
	<link rel="apple-touch-icon" href="images/appleicon.png" /> 
 
	
<!-- GLOBAL JAVASCRIPT --> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery-masterscripts.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			
			$("a#stdzoom").fancybox({
				'titleShow'		: true,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic',
				'overlayOpacity' 	: 0.8,
				'overlayColor' 		: '#666',
				'titlePosition'	: 'over',
				'hideOnContentClick' : 'true'
			});
			
		});
	</script>



	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17525979-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
	</script>
	
	<!-- CONDITIONAL JAVASCRIPT --> 
	<!--[if lt IE 7.]><script defer type="text/javascript" src="js/pngfix.js"></script><![endif]-->



</head>

<body>

<div id="topofpage"></div>


<div id="header">
</div>	      

<div id="container">


	<?php include("includes/header.php"); ?>

	
	
  
     <div id="content"> 



			<div id="position_navmenu">
			
				<?php include("includes/nav.php"); ?>
				
			</div>


			<div id="position_leftcol"> 
			
			
			<img src="images/pageheading_mikesblog.jpg" width="490" height="80" alt="Mike's Blog: Grown up Kid"/> 
			
			
			

   
    <div id="contentload2" class="editable" title="">
<p class="darkertext"><strong>Teach, Don't Bully</strong><br />
  <br /> 
  April 2013
</p>
<div>
  <div>
     <p>&quot;I'd rather be a little nobody than an evil somebody.&quot; - Abraham Lincoln</p>
     <p>I preface this article with the fact that I have procrastinated on writing this a long time. Now is the time!</p>
     <p>I have been bullied. I have been a Bully. I can still be a Bully. I am a Bully.</p>
     <p>These four statements ring true in me and a lot of us. I admit it. I  am not proud of it. I can be selfish, stubborn, and spoiled. I do not  suffer fools. I give a lot of direction to a lot of people and it simply  wears me out to repeat it over and over again.</p>
     <p>Growing up in the 60's, bullying was a way of life in my Americana  neighborhood. It was deep and I hated it. But around eleven or twelve  years old, I became good at it. It was bully or be bullied. I practiced  it a lot until my wife and children called me out on it in the 90's. I  am ashamed of some of the things I have done. I am attempting to make  amends each day. It's something that will never go away in me. I have  learned the hard way that &quot;hurt <em>people</em>, <em>hurt</em> people.&quot; I don't want to be one of those people!</p>
     <p>Nowadays when I go into Bully mode, I know it&rsquo;s time to take a  vacation! I just spent ten days with my family in Florida and New  Orleans. Lucky dude I am!</p>
     <p>I didn't get a lot of rest, too many activities to catch up on!  But  most importantly, I gave my Business Team a rest from me! Two days  before I went on Vacation, I really let some people have it. I was not  happy with our numbers. I was really tired and &ldquo;Mean Mike&rdquo; came out. I  made people cry. I embarrassed others. I embarrassed myself. I'm good at  it. I must remember to control my impatience, and use it  constructively. How, you ask?</p>
     <p>Teach, reinforce, and praise.</p>
     <p>It's quite simple. Tell people what they need to know, what they need  to improve, and praise them when they do it. Welcome your family and  friends each day with a smile and a happy thought. It will make the  tough stuff easier.</p>
     <p> Calvin Coolidge said, &quot; The man who builds a factory builds a  temple, that the man who works there, worships there, and to each is due  not scorn and blame, but reverence and praise! &quot;</p>
     <p>Teach, don't Bully!</p>
  </div>
</div>
<p class="darkertext"><br /> 
  <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now: </strong>Don't miss this great deal!  <a target="_blank" href="http://www.gochampion.net/images/13_Blast_Feb2.jpg" _mce_href="http://www.gochampion.net/images/13blast_Sunglasses.jpg">Click Here.</a></p>
    </div>


					
				<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    				
    				
    				
    				
    			
    			
    			
    			 
    			 <h3>Archives</h3>
				<img src="images/heading_sidebar.png" width="275" height="8" alt="Archives"/>
				<div class="darkertext">
    			 <a href="mikesblog.php">April 2013 - A Little Good News</a>
    			 <ul id="navload">
                               
   <li><a href="pageloads/blog_apr2013.php">April 2013 - Teach! Don't Bully</a></li>
    <li><a href="pageloads/blog_mar2013.php">March 2013 - Remember The Romance</a></li>
  <li><a href="pageloads/blog_feb2013b.php">February 2013 - So God Made an Entrepreneur</a></li>
  <li><a href="pageloads/blog_feb2013a.php">February 2013 - Reunion and Redemption</a></li>
<li><a href="pageloads/blog_Jan2013b.php">January 2013 - WILL Power!</a></li>
<li><a href="pageloads/blog_Jan2013a.php">January 2013 - Fatigue Makes Cowards Of Us All</a></li>
<li><a href="pageloads/blog_dec2012.php">December 2012 - The Bucket List</a></li>
<li><a href="pageloads/blog_dec.php">December 2012 - From the State Orphanage to the State Capitol</a></li>
<li><a href="pageloads/blog_nov2012.php">November 2012 - The Elections are not over!</a></li>
<li><a href="pageloads/blog_octB2012">October 2012 - Friends of a Brave Man!</a></li>
<li><a href="pageloads/blog_2oct12.php">October 2012 - The Retirement Myth</a></li>
<li><a href="pageloads/blog_sept20122.php">September 2012 - Help Suzie Help Abused Children, and Get FREE Stuff!</a></li>
<li><a href="pageloads/blog_sept20121.php">September 2012 - Memphis Rocks!</a></li>
<li><a href="pageloads/blog_sept2012.php">August 2012 - Late Bloomers III: The Solution.</a></li>
<li><a href="pageloads/blog_aug2012.php">August 2012 - Late Bloomers II.</a></li>
<li><a href="pageloads/blog_july2012.php">July 2012 - Late Bloomers.</a></li>
<li><a href="pageloads/blog_june2012.php">June 2012 - Loss in a Leader.</a></li>
<li><a href="pageloads/blog_may2012.php">May 2012 - Leaders in the Making.</a></li>
<li><a href="pageloads/blog_apr12012.php">April 2012 - Here is to the Crazy One's</a></li>
<li><a href="pageloads/blog_apr2012.php">April 2012 - Fifteen Minutes of Terror!</a></li>
<li><a href="pageloads/blog_mar1_2012.php">March 2012 - Planning is Fun, yea right</a></li>
<li><a href="pageloads/blog_mar2012.php">March 2012 - A Lesson learned in the loss of a pet.</a></li>
<li><a href="pageloads/blog_feb2012.php">February 2012 - Humility, good for the Soul and Business.</a></li>
<li><a href="pageloads/blog_jan2012.php">January 2012 - Goal setting, not for the weak of heart.</a></li>
<li><a href="pageloads/blog_dec2011.php">December 2011 - Life is a struggle, but we still LIVE.</a></li>
<li><a href="pageloads/blog_oct2011.php">October 2011 - Power of the T-Shirt</a></li>
<li><a href="pageloads/blog_aug2011.php">Aug 2011 - Buy Memphis Now!</a></li>
<li><a href="pageloads/blog_may12011.php">May 2011 - Children are our greatest asset.</a></li>
<li><a href="pageloads/blog_may2011.php">May 2011 - Dream, Believe and Achieve</a></li>
<li><a href="pageloads/blog_mar2011.php">Mar 2011 - Don't Let the Job Get in the Way of the Job</a></li>
<li><a href="pageloads/blog_feb2011.php">Feb 2011 - It's Time for an Attitude Adjustment</a></li>
<li><a href="pageloads/blog_jan2011.php">Jan 2011 - Start With Why</a></li>
<li><a href="pageloads/blog_dec2010.php">Dec 2010 - Power of Santa Claus</a></li>	
<li><a href="pageloads/blog_nov2010.php">Nov 2010 - Power of Giving Thanks</a></li>	
<li><a href="pageloads/blog_oct2010.php">Oct 2010 - Power of One-One Team</a></li>	
<li><a href="pageloads/blog_sep2010.php">Sep 2010 - Power of One-Volunteer</a></li>	
<li><a href="pageloads/blog_aug2010.php">Aug 2010 - Power of One-No Regret</a></li>		 
<li><a href="pageloads/blog_jul2010.php">Jul 2010 - Power of One-Women</a></li>
<li><a href="pageloads/blog_may2010.php">May 2010 - One Man's Will to Change</a></li>
<li><a href="pageloads/blog_apr2010.php">Apr 2010 - The Power of the Customer</a></li>
<li><a href="pageloads/blog_feb2010.php">Feb 2010 - The Power of Presentation</a></li>
<li><a href="pageloads/blog_jan2010.php">Jan 2010 - Dare to be Great</a></li>
    </ul></div>
    			
    			
    			
    			<h3>Contact</h3>
				<img src="images/heading_sidebar.png" width="275" height="8" alt="Contact"/>	
    			<p class="darkertext">	
				For comments on this months article or general questions for Mike Bowen, email him at <a href="mailto:mike@gochampion.net?Subject=GoChampion.net - BLOG">mike@gochampion.net</a>.
				
				<br/><br/>
				
				<a href="http://www.facebook.com/people/Mike-Bowen/1040078256"><img src="images/facebookicon-large.jpg" width="30" height="32" alt="Facebook Icon"/>	</a>
			
				
				</p>
				
				
				
			</div>




  	</div>   
 	 

	<div id="footer">

		<?php include("includes/footer.php"); ?>
	
	</div>
	
	
</div>


</body>
</html>