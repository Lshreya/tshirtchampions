
    <div id="contentload2"> 
		<p class="darkertext">	
			<i>Power of One (Part II)</i><br/><br/>
<strong>Dare to be Great</strong><br/><br/>
January 2010<br/><br/><br/>


 The only way to be great is to set goals. It's OK even if you don't achieve all of them, all the time. The greatness comes in the sheer laying of your soul on the line everyday in the pursuit of something you believe in.<br/><br/>
In my November blast Power of One; I spoke about the power of one simple Thank You note a day. You may not remember, but just sending one note each business day to someone you met, is a minimum of 260 notes a year! I have become pretty good at this over the years. So a couple of years ago I defined the Power of One in other daily activities for my Customer Care Team.<br/><br/>
     When I came back to the family business in 1982, my brother was already a super salesman. He always had that carefree quality that everyone noticed right away. I on the other hand was always way too intense and serious. Growing up I was better at most things than Kenny, but not selling. He was a natural, so naturally he had the biggest accounts and rightfully so. He had Coke; I had Pepsi; he had Baptist Hospital, and I had Methodist Hospital. He had Cotton Carnival; I had Memphis in May. You get the idea.... We had absolutely no formal training. We knew we had to sell more each month to get a raise. By the way, my brother is still the best salesperson I have ever known. Once I walked into my Dad's office telling him I had no more leads (he by the way was not a salesman, he was a production and buying expert), he just laughed. He reached into the drawer and threw the yellow pages at my feet and said "don't come back to my office until you finish the Z's." So needless to say, we made a lot of phone calls 50 to 100 a day. Some days I might just get one person to actually listen to me.
     <br/><br/>
     One day though, someone at Memphis in May gave me the name of the lady over the MIM Run on the River. In 1983 this was a 5000-person event and they all needed t-shirts! This was by far the largest order for which I had a chance in my short career. Ms Dot Work, head of marketing, was a tough cookie in her 50's, and I was in my 20's. I was so scared of calling her. She agreed to see me and give me a chance to bid. A couple of days later I won the order! I went back to the
office to tell my dad and he asked me about the 50% deposit. Uh Oh! You see, we had to get a 50% deposit on every order back then so we
could afford to buy the blank t-shirts. What was I going to do? Well, I called her again and told her the truth and you know what; She said
"No problem, come get the check tomorrow." The day I picked up that check was the day I became a super salesman in my mind.  It all
started with a simple phone call. Yes, you may have to make 100's or even 1000's of phone calls to get to "The One" that makes you feel
like a superstar. Set a goal of really talking to one new customer each day. It may take some practice but you can do it.
Remember: For a company to be great, you first have to believe you are great. I promise you will get the Power of One on your side if you
Dare to be Great!

<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now here’s the pitch:</strong> Allow your employees to feel great with company logo apparel. Let us set up a digital ordering system for your official
company merchandise. Click Here for the deal.  Hugs, MB.
			
    				
			
			
			</p>
    </div>