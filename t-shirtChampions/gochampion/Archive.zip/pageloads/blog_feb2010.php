
    <div id="contentload2"> 
		<p class="darkertext">	
			<i>Power of One (Part III)</i><br/><br/>
<strong>The Power of the Presentation</strong><br/><br/>
February 2010<br/><br/><br/>


This Power of One is number three in a five part series of small daily goals. I ask my Customer Care Team to report their Power of One's each day. I came up with this idea, after reading Sheldon Bowles "Raving Fans". He introduced the idea that achievements in our careers can be broken down into giving extra 1% effort in everyday activities.
<br/><br/>
    Previously, I have reviewed the Power of the Thank-you note, and the Power of the phone call. Today, I am going to expound (we certainly didn't use this word in Parkway Village) upon the importance of the Power of the Presentation. I was always pretty good at meeting people. I loved talking about my self and our family business. I lived for the sales calls. My brother and I would make five to ten calls a day back in the early 80's. Of course that was when you could drive across town in twenty minutes. Today, you're lucky if you can get three to five person-to-person presentations a day.
<br/><br/>
    As I have said before, my brother Kenny was always a better salesman than I was. To tell you the truth, it spawned a heated rivalry. We would head out each day with our samples and our catalogs. He would always come back with more orders.  For a long time, I blamed it on everything except me. He had better customers. He gave cheaper prices. He had more customers, etc, etc, etc. One day in one of our many passionate discussions (that's code for fights, for those of you who knew us) he blurted out his secret. "Did you offer something that they wanted?!". At that moment I can still remember bells going off. I actually heard him. You see, I was really good at talking, but one terrible listener. I was always coming back after an appointment saying they really liked me but I didn't get an order.  Kenny went on to say, your job as a salesman is get them to give you an opportunity to serve them. What I wasn't doing, was listening for exactly what the customer really wanted. The salesman's job is to really listen much more than to blurt out his offerings. Zig Zigler said, "you give enough people what they want and you will get what you want." Yes, you have 
to have a good product.  You have to get in the door. You have to have competitive prices. But it all still boils down to your customer believing 
that you will give him what he wants. Hence, the term Zig coined, " We really are all "want providers."
<br/><br/>
Oh, by the way, not long after learning these valuable lessons, Kenny and I both sold our first million dollars per year. We went on together to 
grow our little company to be on Inc Magazine's 500 Fastest Growing Companies in the country 4 years in a row 85,86,87,and 88.
<br/><br/>
    Do your homework, and listen to the customer for his wants and needs. Ask for the opportunity to serve your customers and you will 
succeed!

<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now here’s the pitch:</strong> T-Shirt season, you can't beat this promotional T-Shirt deal. If you can, call me!! 
Click Here for the deal. Hugs, MB.
			
    				
			
			
			</p>
    </div>