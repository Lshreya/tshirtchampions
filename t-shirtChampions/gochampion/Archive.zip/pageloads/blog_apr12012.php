    <div id="contentload2" class="editable" title=""><p class="darkertext"><strong>Here is to the Crazy One's</strong><br />
    <br />
April 2012</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;   </p>
  <div>
    <div>
      <div>
        <div>
          <p>Create a vision.  Set goals, schedule and act upon them.  Commit to a  mission. Create core values and a team culture. Never give up. I  have passed on a little of the basics of business that I have learned in  the last thirty-five years. But you know, we also should continue to  learn and change and grow.</p>
          <p>      One way I keep the creative fire burning is to judge the  Memphis Business Journal's Small Business Awards. Champion has a  relationship with this prestigious honor since its inception  almost thirty years ago. We have been finalists in the process. Back in  1986, we lost to that pillar of the community, Hub Cap Annie! We sponsor  the Awards for the MBJ Dinner (go figure). My mom was a judge  for ten years. I took her place for the last five. This year we both  were able to sit on the panel of judges at the same time. I am going to  attempt to scream at the top of my lungs the excitement the finalists  instill in me. CAN YOU HEAR ME!!! The Finalists are all Winners and  Brilliant!!!!</p>
          <p>     The process is so fun. Hundreds of businesses across the  community are nominated by customers, vendors or employees. The MBJ  editorial staff chooses five finalists in 3 categories based on the  amount of employees. One category is dedicated to The Small Business  Executive of the Year. The businesses must submit to some pretty darn  close scrutiny. Vision, financing, job creation, community involvement,  profitability and a host of other considerations, separate the good ones  from the Great ones!</p>
          <p>    Five judges, all entrepreneurs in their own right, individually  visit a finalist in each category at the finalist&rsquo;s business.   The real  fun part begins when we hear from each of the CEO' s, partners,  founders and team members in a panel setting over a two-day period. This  is when you can really tell who has their act together. For two solid  days, I sit and steal their wonderful ideas. Steal is a&quot; Parkway  Village&quot; term for creative research.</p>
          <p> 1.     Platform building to insure repeatability of your services!</p>
          <p>2.     Full payment of insurance is better compensation than a raise!</p>
          <p>3.     A small life insurance policy for each team member! (To insure a proper burial if needed)</p>
          <p>4.     Go meet all your neighbors around your business for 2 miles!</p>
          <p>5.     Workflow efficiency can net more money than some sales!</p>
          <p>6.     Help people that Value your judgment, stay away from others!</p>
          <p>7.     Provide 360 evaluations for peer to peer!</p>
          <p>8.     Compensation based on profit of company or department goals, not seniority!</p>
          <p>9.     Establish a definitive culture and keep only who buys into it!</p>
          <p>10.  Be a leader of your community, employees, and most importantly your family!  </p>
          <p>So you see a fraction of these ideas that flow over the two days. It  is very hard to choose one winner, because they are all winners! So how  do I judge? </p>
          <p> &quot;I knew my company was going to be a success from the very  beginning. Because I planned what it would look like when it was  complete&rdquo; Thomas Watson, founder of IBM</p>
          <p> When I read this quote about three years ago, I knew then, that  would be the basis of how I would choose the winners of these awards.  Who was crazy enough to look that far into the future and believe!!</p>
          <p>     Obviously I am right!   I was honored to attend my first Society  of Entrepreneurs, Master Entrepreneur Gala on Saturday. On the table  was a small booklet of quotes that was titled &quot;Here's to the Crazy  Ones&quot;. It contained quotes from all the Master Entrepreneurs in Memphis.  On the front page was the best one of all:</p>
          <p>&quot;Here's to the crazy ones, the misfits, the rebels. The  troublemakers, the round pegs in the square holes.... the ones who see  things differently- they're not fond of rules. You can quote them,  disagree with them, glorify or vilify them but the only thing you can't  do is ignore them because they change things.... they push the human  race forward, and while some may see them as the crazy ones, we see  genius, because the ones who are crazy enough to think they can change  the world, are the ones that do.&quot;  Steve Jobs</p>
          <p>  Memphis and our surrounding communities should celebrate that we  have some wonderfully crazy people and businesses in our community! </p>
        </div>
      </div>
      <p class="darkertext"><br />
        <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now:</strong>&nbsp;Here's to the crazy ones with this crazy offer!! <a target="_blank" href="http://www.gochampion.net/images/12ChampionPerformanceTee1.jpg">Click Here.</a></p>
  <p>&nbsp;</p></div></div>
<p class="darkertext">&nbsp;</p></div>
<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>