
    <div id="contentload2"> 
		<p class="darkertext">
		
		
		
		<i>Power of One (Part VI)</i><br/><br/>
<strong>Power of One-Women</strong><br/><br/>
July 2010<br/><br/><br/>

     There is an old saying, "Behind every successful man there is a good woman." Well I submit to you the real truth. Behind every successful woman is a man or men wanting to make her proud of them.  I say this because this has been not only my observance after 53 years, but certainly my experience.
<br/><br/>
    Without women in this world, men would probably wage war on each other even more than we do today. Our society would be run by the "Who's got the Biggest Ego".
<br/><br/>
    "How can woman be expected to be happy with a man who insists on treating her as if she were a perfectly normal human being" ~ Oscar Wilde
<br/><br/>
    In the Movie Peter-Pan, Peter is told in order to get back home, he has to think of his "Happy Place". His happy place ends up being with his wife &amp;amp; daughter. Women are in a word the "Happy" part of my life. Where do I start with all the unheralded women that have helped me become the man I've come to be.
<br/><br/>
    It is safe for me to say that the women in my life (Friends, Teachers, Nurses, Customers and Employees) are all more important than I have acknowledged.
<br/><br/>
    There are so many women in my life. My grandmothers, who both were not treated very well by the men in their lives.  Till the very end, they were still sensitive, loving and caring. Even though they have moved on to a better place, they left a warm spot in my heart that will be there forever.
<br/><br/>
    First of all thanks to my mother and sister in laws for graciously accepting me into their families for over 30 years now. Thanks to my dad and my brother's wives' for caring about them as much as I do. Beautiful, fun loving Aunt Polly &amp; Aunt Charlotte. Both have been dear friends over the years and there is no better test of a friendship than when you really need them. They were both always there.
<br/><br/>
    My Mom, I certainly don't have the space in this column to describe all my feelings for her. "Men are what their mothers made them". ~  Ralph Waldo Emerson.  This quote is only a satisfactory summation. Let's just say that she has been the greatest single influence on my character, my beliefs &amp; still my mentor.
<br/><br/>
    My Wife, Suzie, is my best friend, the mother of my children, personal chef, lover, business partner, interior designer, caregiver and psychologist.  She picked me up when I was lowest &amp; stayed behind me when I fell again. She is still the kindest, gentlest, really, really, beautiful inside &amp; out person I have ever met. Ok did I say lover? I have been so fortunate for her to allow me to live with her for almost 32 years.
<br/><br/>
To sum up the Power of Women: I will leave you to this quote by Mother Teresa:
<br/><br/>
    "Spread love everywhere you go. First of all in your own home. Give love to your children, then your husband, to the next door neighbor... Let no one ever come to you without leaving better and happier. Be the living expression of God's kindness.  Kindness in your face, in your eyes, in your smile, kindness in your warm greeting."
<br/><br/>
    Now, to all you tough men out there. Hug the women in your life today &amp; everyday. Tell them how important they are to you. I promise you will be a better man for it.
<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now Here's the Pitch:</strong> Its Cap Time in the South. Get the best caps at the lowest prices this month from Champion. Click <a href="http://r20.rs6.net/tn.jsp?et=1103532390541&amp;s=0&amp;e=001HiLSlEy5CAR0-vd4A1HhPHbnBJ04zUQK7AJuT9tt0XlRiaeTxAeww9o6_YC7Pp6-WxPkJPjdjqpv04FS3CiWnEiRxZ4AQSRdpnjsluGXT7yFHCJH5VYsViTRwA8jJqeZAObkNBYmRVmt4EjIwNwD0Q==">Here</a> for the deal.
    				
			
			
			</p>
    </div>