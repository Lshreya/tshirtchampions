
    <div id="contentload2"> 
		<p class="darkertext"><strong>Dream, Believe and Achieve</strong><br />
		  <br />
May 2011<br />
<br />
<br />
I do a lot of speaking to various groups such as high schools, community groups, Fraternities and an occasional visit to University of Memphis and Southwest Community College. I get calls mainly because of my rate..FREE! Some people say I would talk to a post. But, I do have a small business success story to tell. I also speak on goal setting and life skills. <br />
<br />
Most everyone wants to know “the secret to our success”. I say lets define it first. What do you think is success? <br />
<br />
• For some, success is achieving goals, being effective and being fulfilled by your work.<br />
• For some, success is defined by the joy you feel. When you do your work and the joy you and others feel as a result of your work.<br />
• For some, success is making a difference in and contributing to family, friends, or community. “The footprints in the greater good.”<br />
• For some, success is the balance between work and the rest of your life. Good job, spiritual growth, and physical well-being. <br />
<br />
How do I define success? Yes to all of the above.<br />
But I sum up all of the above in a simple goal for myself: “Love what I have.&quot; Let me say that again. &quot;Love what I have.” The freedom to have a family, work, play, volunteer, and worship is Success. <br />
<br />
Now, if I don't have what I want, then I dream it, believe it and achieve it!!! <br />
<br />
DREAM<br />
So let us talk about dreams. What are some of your dreams? Do we stop dreaming because we grow old, or grow old because we stop dreaming? The only difference between a dream and a goal is commitment. To commit, we have to write our dreams down. If you don't write them down, then dreams are wishes that get forgotten during this thing we call living. <br />
<br />
So how do we get started with recording dreams or goals? Make a list, I love saying, “When in doubt, write it out.” Write down 5 things you want to do every day. That's it, pretty simple huh. <br />
<br />
BELIEVE<br />
Once you have listed your personal and business goals (I have approximately 50 on my list at all times) its time to develop a vision statement. A vision statement is a succinct sentence or paragraph of how your life will look after it is completed. Record your vision in five-year segments. It will be easier that way. <br />
<br />
To really give the vision of your life a purpose, you must above all else, believe in yourself. If you don't why should anyone else? Don't you know that how you treat others is in direct relationship to how much you care about yourself? Its true, I looked it up. <br />
<br />
ACHIEVE<br />
How do we get started achieving belief in ourselves? Schedule all of those dreams you wrote down. You must put them on a calendar. Just pick a date. If you don't make it by that date, move it. This is your action plan to achieve. An action plan consists of simply achieving miniature goals each day. A study schedule, a work schedule, a play schedule, yes even a play schedule! <br />
<br />
Remember: achieve something for you each day. Achievement is the journey of getting better. You have an obligation to yourself and the people around you to simply exceed expectations. <br />
<br />
You now have my secrets of dreaming, believing and achieving. If you need help, ask for it. The most successful people in the world have the most partnerships. Practice, practice, practice and you will not fail. Failure is the act of ceasing to try. Don't ever quit. <br />
<br />
Dream, Believe, Achieve and be Happy! <br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now Here's the Pitch:</strong>Champion Awards and Apparel will not be beat on price for custom printed t-shirts. Call or email me today. I guarantee you we will match or beat any price on screen printed t-shirts.<br/>
<a href="mailto:mike@gochampion.net">mike@gochampion.net</a> or (901) 870-4830  				
			
			
	  </p>
</div>


					
				<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>