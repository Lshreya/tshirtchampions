    <div id="contentload2" class="editable" title=""><p class="darkertext"><strong>Leaders in the making.</strong><br />
    <br />
May 2012</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;   </p>
  <div>
    <div>
      <div>
        <div>
          <p>This article is unabashedly about how proud I am of my second born son, Michael. Last Saturday, he graduated Magna Cum Laude with Honors from the University of Memphis. He obtained a degree in International Business and minor in Finance. Yes, he is obviously way smarter than his dad!</p>
          <p> This journey really began when Michael came to me when he was fifteen after he had finished his sophomore year at CBHS. By the way, Soccer and sports had been a big part of his life. CBHS was currently ranked third in the nation at that time. His main goal had been to become a starter on the team for his junior year. A good goal, but a little shortsighted for someone so talented.  Michael went on to relay to me his new plan for his future. &quot;Dad, I'm finished with soccer. I've done all I can do. It's not going to help me get where I want to go. Naturally, he got my attention at that moment. &quot;I want to make a minimum 3.5 GPA, work at Champion, get a truck, and a girlfriend,&quot; he said. He also said he wanted to be awarded n academic scholarship to the University of Memphis and become a leader. He said he wanted to make it a better place.  He also was thinking of going to its new Law School on an academic ride so he didn't have to use his college savings. I was astounded that goal setting was alive and well in this young man!</p>
          <p> You see, when our sons were ten years old, we told them that we were saving a college fund for them. We explained to them that they could have the remaining money they didn't use if they received a scholarship. If they did not graduate, they would receive the funds at age twenty-five, only to purchase a home. Our first born, Colby did just that and is perusing a career at Champion. We said this, hoping our sons would realize they didn't really need our money. Well it worked!</p>
          <p> Below, is my speech at Michael's graduation celebration last Saturday:</p>
          <p> There are never enough moments in a parent's life of feeling that you've done good in helping your children become better people.</p>
          <p>This is one of those precious moments where Suzie and I are glowing with Thankfulness, Humility, and Pride all at the same time.</p>
          <p>First, We are thankful to all of his family for helping us to help Michael along this journey.</p>
          <p>He learned a love of golf from his brother Colby, Colby also will be the future of the family business. This was a load off Michael, I can assure you.</p>
          <p>He learned a love of hunting and fishing from Mike and Hunter Scott, Bill Kinkade and Tony Toarmina.</p>
          <p>He learned brotherhood and teamwork from his SAE fraternity brothers, who some have been together now 8 years, since the CBHS days. Michael was named one of the top four leaders in the Country for SAE in 2011!</p>
          <p>He learned love and thoughtfulness from his grandmother Dot.</p>
          <p>He had support from his uncles, cousins, and Grandparents Marris and Jerrie.</p>
          <p>He learned how to work in the family business with his cousin Brandon.</p>
          <p>He learned leadership skills and loyalty from my best friends and coworkers <br />
            Bill and Debbie Kinkade and Tony Toarmina .</p>
          <p>He learned a love for the world outside of the United States from his Grandma Lane. His Grandma Lane and he traveled to 5 continents including South America, Europe, Africa, and Asia, over 30 countries and 35 states.</p>
          <p>I also think that he gained an admiration for the law thru his Grandpa Hunter. Hunter was his friend on many of those travels and showed him the importance of friendship as he had friends all over the world.</p>
          <p>Most of all he learned love and acceptance from his Mom, who was always his quiet and calm advisor.</p>
          <p>Humility, that we are so lucky to have not 1 but 2 wonderful sons.</p>
          <p>Humility, that all of you are here to celebrate this wondrous occasion.</p>
          <p>Humility, that you were a major part of helping us to teach these young men to preserver and succeed. We are truly thankful for your blessings upon us.</p>
          <p>Pride, that Michael is the first Bowen to graduate college.</p>
          <p>Pride that Michael is going to Tulane Law in August.</p>
          <p>Pride, that Michael has become a leader of men and a scholar of letters!</p>
          <p>There is an old saying, &quot;You don't raise heroes, you raise sons. And if you treat them like sons they become heroes. Even if in your own eyes! &quot;</p>
          <p>Here's to Michael Bowen, my son, my friend and my Hero!!!</p>
          <p>Also, here's to all the graduates all over our great city. May you learn and grow and help to make Memphis a great city of the future!</p>
        </div>
      </div>
      <p class="darkertext"><br />
        <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now:</strong>&nbsp;Beat the heat with Performance Polos. <a href="http://www.gochampion.net/images/12ChampionPerformanceTee1.jpg" target="_blank">Click Here.</a></p>
  <p>&nbsp;</p></div></div>
<p class="darkertext">&nbsp;</p></div>
<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>