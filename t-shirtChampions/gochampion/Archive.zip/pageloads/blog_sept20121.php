    <div id="contentload2" class="editable" title=""><p class="darkertext"><strong>Memphis Rocks!</strong><br />
    <br />
September 2012</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;   </p>
  <div>
    <div>
      <p>       Back in May of this year, I got a call from Jeremy Park of Lipscomb Pitts Breakfast Club. Normally that means Jeremy has some great new idea to promote Memphis. For those of you who don't know, Champion is a member of the LPBC, an organization of 60 plus businesses that promote Memphis and with 150 plus events a year, bring in leaders from across the world on a monthly basis in a breakfast format. For more info, please go to <a href="http://www.lpbreakfastclub.com">www.lpbreakfastclub.com</a>.</p>
      <p> Jeremy is a dynamic young man from California that smartly decided to marry a good ol Southern Belle and raise his family in Memphis. Jeremy and I met 3 years ago and like many new young intelligent  &quot;outsiders&quot;, he just couldn't understand why Memphians and especially our neighbors have this inate inferiority complex about our great city.</p>
      <p> Being someone that grew up in Memphis and has been proud of our city all my life, we hit it off quite well. Still I didn't want to go to any breakfast meeting at 7:00 in the morning nine times a year. I am definitely not a morning person and wisely have managers of Champion who happen to like mornings. Needless to say, Champion didn't join the &quot;club&quot; right away. But I digress.</p>
      <p> Back to the story. Jeremy asked me in all my 35 years of designing t-shirts what was the best slogan about Memphis? Before I could answer, he started rambling on that the LPBC can lead the way with a new positive slogan about Memphis. He blurted out Memphis Rocks! After all, Memphis is the Home of the Blues and the Birthplace of Rock n Roll, but in reality it is so much more. So Champion's designers set out to portray all the good things about Memphis in one design. What a chore! After many different versions, (it seems Jeremy hasn't stopped yet), we came up with an absolute slogan and salute to the people and places that make Memphis a great place to live work and play. After all, it really is about our people. We take Memphians for granted way too often. I also have taken the liberty of exclaiming my top ten reasons why I think MEMPHIS ROCKS!!!!<br />
        <br />
        #1 Memphians are friendly! We smile and we speak to each other! We are also famous! Rolling Stone says, &quot;Memphis has had more influence over modern music than any other city in the world! &quot; (see the Memphis Rocks tee for all our legends)<br />
        <br />
        #2 Memphians loves to help people we don't even know! We are the 7th most giving city in the country per our income. Wow!<br />
        <br />
        #3 Memphis has the cleanest and best water in the world!<br />
        <br />
        #4 Memphis has the most trees and land mass per capita in the country and the largest inner-city park, Shelby Farms, in the world!<br />
        <br />
        #5 Memphis is America's Distribution center of the country. Because of this, Memphians have the best and least expensive access to fresh vegetables, fruits, food, and various other goods than anywhere in the world.  Our Agriculturally based neighbors are indisputably good to Memphians with the local food.<br />
        <br />
        #6 Memphis is the Biomedical center of the south. Memphians receive some of the most modern medical treatment in the world.<br />
        <br />
        #7 Memphis has half the cost of living than any other major metropolitan cities! For example, free days at the worlds best Zoo! 5.00 tickets for NBA (Memphis Grizzlies), 5.00 tickets for Triple A baseball (Memphis Redbirds), as well as Broadway plays at half price! Housing is less expensive than any other major metropolitan area.<br />
        <br />
        #8 Memphis has world class landmarks and festivals galore! Graceland, Beale Street, the Mighty Mississippi River, Memphis In May, CooperYoung Arts Festival, River Arts Festival, AutoZone Libertybowl, Southern  Heritage Classic, and I haven't even begun to scratch the surface!<br />
        <br />
        #9 Memphians have access to the best education in the world! University of Memphis, UT Medical, Rhodes College, CBU, CBHS, MUS, St. Georges, WhiteStation Hig Houston High! Montessori schools, Kip schools ect...<br />
        <br />
        #10 Memphians are some of the most sensitive, diverse, and tolerant people in the World! Simply put this is an easy place to live, worship, and raise a family however you see fit within the law. Speaking of Law, we have the best Police, Sherriff, Wildlife and Fire Departments in the South!<br />
        <br />
        Send me your Memphis Rocks example!!  With every Memphis Rocks T- shirt sold, Champion is donating 10.00 to the Fallen Officer Memorial. We need $1 Million dollars to Honor our heroes appropriately. Please help in this small way!</p>
      <p> </p>
    </div>
  </div>
  <p class="darkertext"><br />
    <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now:</strong>&nbsp;<a href="http://205.186.132.94/email/link.php?M=12921&amp;N=46&amp;L=48&amp;F=H" target="_blank">Click here</a> for your Memphis Rocks tee special today  Two tees for only $25.00 (includes shipping) this month only.</p>
<p class="darkertext"></p>
  <div><div></div></div>
<p class="darkertext">&nbsp;</p></div>
<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>