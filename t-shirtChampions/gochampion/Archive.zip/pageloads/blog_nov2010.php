
    <div id="contentload2"> 
		<p class="darkertext">


<i>Power of One (Part X)</i><br/><br/>
<strong>The Power of Giving Thanks</strong><br/><br/>
November 2010<br/><br/><br/>



This normally is not a good time of year for me. Blame it on the lack of sun. I think they call it SAD, (seasonal affective disorder). I call it just a tough time of year for my business. For most of my adult life the next four months are hard on the ol' profit and loss statement. Unfortunately, a lot of my disposition still hinges upon whether I win or lose the month financially. I hate to lose. 
<br/><br/>
Yes, I'm whining. I do it well! I have the bit*****, down to a science. Yea, I said it, I can be a big pain in the a**. 
<br/><br/>
So, this year I am going to try harder to break the B syndrome as I call it. What's my secret you ask? It's not really a secret it's a plan. The plan consists of all the things we were taught to do as a child. We don't forget them; we just allow all these other layers of life to cover them up. 
<br/><br/>
So here goes my list:
<br/><br/>
• Eat the right foods<br/>
• Drink lots of water, less other stuff<br/>
• Sleep when your tired, naps are ok<br/>
• Exercise at least 30 minutes every other day (if you skip a day, that's ok, just double up. If you can't do 30 min. Do 15 and build from there.)<br/>
• Play outside as much as possible (jump in some leaves, hug a tree)<br/>
• Be nice to everyone or leave.<br/>
• Tell my friends that they are my friends and they will be forever. Remember, forever is not that long off.<br/>
• Hug and tell loved ones, I love you.<br/>
• If my back hurts, think of the person who can't get out of bed.<br/>
• If the stress of work gets to me, think of those without a job.<br/>
• If my bills pile up, think of those without bills, because, well they're just without.<br/>
• If my employees bug me, just think if I had bad employees (mine are all great)<br/>
• If I'm having a troubled day, just say I can't wait till tomorrow, because it's going to be better. The real saying is I can't wait till tomorrow because I get better looking everyday. But that hasn't worked in my case.<br/>
• Give thanks for my parents, brother, aunts, uncles, cousins, nephews, nieces, and don't forget the in-laws, still alive and well.<br/>
• Give thanks for my 2 wonderful sons.<br/>
• Give thanks for my loving wife of 30 years. <br/><br/>

By now, you get the idea. Give thanks everyday for something. I feel better already. I hope you do to! Happy Happy Thanksgiving! <br/><br/>

Thanks for reading. M 


<br/><br/><br/>
<img src="images/pitch.jpg" width="54" height="49" alt="Pitch graphic"/><br/>
<strong>Now Here's the Pitch:</strong> This season, thank your customers and employees with a small token they will keep and remember. There is still time! Branded gifts to fit all budgets. Call 365-4830 or e-mail me today.  				
			
			
			</p>
			</div>


					
				<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>