    <div id="contentload2" class="editable" title="">
  <p class="darkertext"><strong>Help Suzie, Help Abused Children, and Get FREE Stuff!</strong><br />
    <br />
September 2012</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;   </p>
  <div>
    <div>
      <p>     This is a repeat of last week’s blog to help abused children.</p>
      <p>I am simplifying the offer to really help abused children. If you buy  2 CASA raffle tickets at $10.00 each, you will receive a free Lawn  Pass. Only 16 passes remain to this weeks Bonnie Raitt concert at Live  at the Garden. Call Suzie at (901) 921-8362 today to get your tickets  and help abused kids. Also you will receive a chance at a free Ipad!!!</p>
      <p>   I don’t normally make such an unabashed appeal for help for my  wife. But, this month, I'm taking a stand for her. That's what we do in  our Family and businesses, take a stand and try to make a difference.  After all she has only put up with me for over 34 years! Whew! It was  hard for me to put up with myself for the past 34 years! You can only  imagine the crap she's been through!</p>
      <p>   I don't have enough space here to even begin, so I will leave that  to your creative imaginations. Let's just say there is a place in  heaven already reserved for her. She is the mother of my children, the  very conscience of my soul, my best friend, and my guiding light!</p>
      <p>   So, in the summer, when she told me she had been elevated to  President of Court Appointed Special Advocates, CASA, for Abused  Children, I knew I needed to tread lightly.Suzie is not your normal,  outspoken RAH! RAH! leader. She has her own quiet style of grace and  consistency. She is an accountant after all. I can assure you I have her  blessing for this plea for help!</p>
      <p>   First, a little background information. Suzie became a CASA,  three years ago. They are the group trained to go into homes where child  abuse has allegedly occurred and inspect the premises to see if the  home and parent or Guardian is fit. She became trained. Her first case  she came back crying that we needed to buy these children an A/C and a  couch. I simply asked why? She told me the house was 106 degrees and  there was no place to conduct an interview because there was no  furniture. This happens everyday in our city. This is called child abuse  and neglect. Simply put, the CASA is the only voice some of these kids  have. There are over 200 cases reported daily! Let that sink in a  moment. That’s what is reported. The actual estimate is an additional  400 each day go unreported. Wow, wow, wow!!! Unbelievable.</p>
      <p>   These kids need CASA, and CASA needs you! I’m here to say it’s  easy to help, and I’m going to make it even easier. So lets get to the  free stuff!</p>
      <p>   Who wants to go to see Bonnie Raitt at the last Live at the Garden  on Friday, October 5? Champion has 20 ground tickets and 5 VIP parking  tickets left for you to purchase at 40.00 each. If you purchase a ticket  before next Thursday, you will not only receive the ticket, but you  will also receive 2 free CASA raffle tickets valued at 10.00 each, for a  chance at:</p>
      <p>*  New IPad,</p>
      <p>*  $500.00 prepaid VISA</p>
      <p>*  $500.00 James Avery sterling silver bracelet and earrings</p>
      <p>*  Go to <a href="http://memphiscasa.org" _mce_href="http://memphiscasa.org">memphiscasa.org</a> for more prizes!</p>
      <p>You will also receive an official Memphis Rocks tee, a $ 20.00 value ( see below) absolutely free of charge.</p>
      <p>So lets review, we can raise over $1000.00 (my personal goal) for  Suzie. You get to go to Bonnie Raitt. You get free chances to win some  cool stuff. You also get a free Memphis Rocks Tee!!! (A $75.00 value for  only $40.00 bucks!)</p>
      <p>Well, there you have it! Looks like a deal to good to pass up. But I'm a little biased.</p>
      <p>Call Suzie today at 921- 8362, <a href="mailto:suzie@gochampion.net" _mce_href="mailto:suzie@gochampion.net">suzie@gochampion.net</a>.</p>
      <p>She can take your cc over the phone and pull reserve tickets and tees for you to pick up from Champion.</p>
      <p>We have one week to raise this $ 1000.00.</p>
      <p>Suzie Rocks, CASA Rocks, Memphis Rocks!!</p>
<p> </p>
    </div>
  </div>
  <p class="darkertext"><br />
    <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now:</strong>&nbsp;<a href="http://205.186.132.94/email/link.php?M=12921&amp;N=46&amp;L=48&amp;F=H" target="_blank">Click here</a> for your Memphis Rocks tee special today  Two tees for only $25.00 (includes shipping) this month only.</p>
<p class="darkertext"></p>
  <div><div></div></div>
<p class="darkertext">&nbsp;</p></div>
<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>