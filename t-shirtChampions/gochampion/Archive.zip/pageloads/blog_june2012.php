    <div id="contentload2" class="editable" title=""><p class="darkertext"><strong>Loss of a Leader.</strong><br />
    <br />
June 2012</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;   </p>
  <div>
    <div>
      <p>Ok, Ok, Ok, today will be the day! This is what I have been telling  my conscious every morning now for a month. I have procrastinated in  writing this next message. I'm good at it. I just haven't had the  courage.</p>
      <p>    James Hunter Lane Jr. passed from this world in April 2012 after  82 years of a grand life. It still seems like yesterday. I lost a big  brother I never had, a teacher, a father figure, a grandfather to  my boys, a husband to my mom, most of all a friend. You know what a  friend is in the tough brotherhood of a mans world? A guy you call if  you're in jail at 3:00 in the morning and he doesn't ask questions. He  just finds the bail and comes and gets you out! Hunter was that guy! He  was that guy to 100's maybe 1000's of people all thru his life.</p>
      <p>     Bill Haltom, author, attorney and friend of Hunter's wrote in  his article in April, &quot;I knew Hunter Lane before I even met him!&quot; Ditto  Bill! In 1967, Hunter ran for Mayor of Memphis and was soundly beaten by  that scoundrel Henry Loeb. Growing up in a liberal Democrat family and  even at the young age of ten years old, I was banging political signs in  yards for my mom for Bill Morris or Bill Ingram, whichever one was  running for something. I only vaguely remember hearing Hunter speak  once. But he was good-looking, tall, strong, (always compared to Ernest  Hemingway) and well spoken. Hunter was the most well read man I ever  knew. Also he was the very essence of Leader with a capital L. You know  the type, Captain and quarterback of Central High Football team in 1949  that beat the CBC Brothers in the State Championship that year. He kept  the game ball proudly in his library for over 64 years! After graduating  from Washington and Lee University, Hunter proudly served in the  Marines in JAG corps. He came home and made Lt. Colonel in reserves,  serving in the Marines for over twenty-eight years. He became a Civic  Leader, a man of the downtrodden and oppressed, instantly with Lucius  Burch, Bill Morris, Bill Ingram and all the men of the 1940's era that  knew Memphis had to change. (<a href="http://www.legacy.com/obituaries/commercialappeal/obituary.aspx?n=james-hunter-lane&amp;pid=157202642&amp;fhid=3693" _mce_href="http://www.legacy.com/obituaries/commercialappeal/obituary.aspx?n=james-hunter-lane&amp;pid=157202642&amp;fhid=3693">Click here for full Obit</a>) His accomplishments will simply amaze you!</p>
      <p>    I lost touch with Hunter for twenty-five years while growing up. I  did know he was known as a great empathizer for minorities in Memphis. I  was lucky to be taught as a child of the sixties, that all people were  created equal. Hunter stood for Civil Rights at a time when it was very  controversial. He even received a bomb threat for voting for Busing as a  member of the school board in 1971.</p>
      <p>We only spoke of his mayoral defeat once about 10 years ago. He knew  he was going to be defeated. But he wanted his say, so he spent a lot of  his own money to have his say.</p>
      <p>    I asked him what did he think would have happened differently if  he had been elected Mayor in 1967?  He softly said,&quot;Dr. King would not  have had a reason to come to Memphis therefore he would not have been  shot.&quot; I asked him to explain.  Hunter cited King's quote in &quot;Letter  from Birmingham Jail&rdquo;, &quot;One has not a legal but a moral  responsibility to obey just laws. Conversely, one has a moral  responsibility to disobey unjust laws.&quot; Hunter went on to say &quot;That the  law of the day preventing &quot;garbage workers &quot;as they were called then  could not strike after not being allowed to bargain was an unjust law.&quot;  He would not have let it get to the stage it escalated to virtually over  a nickel an hour wage increase.</p>
      <p>    How would you like to live for forty-five years with the thought  that you could have changed history and did not get the chance?  He survived it, but never forgot it!</p>
      <p>   Ending on a cheerful note, he loved the Little Red River and trout  fishing. The river soothed him as it does me to this day.  But he  couldn't see very well to rig the poles.  On his seventy-fifth birthday,  my son and I took him on a guided trip down the river. We caught and  released over Seventy-five rainbow trout in three hours. We just had a  blast. We still have the Little Red Tree House on the Little Red River  and we will never let go of our memories of Hunter.</p>
      Simply said, I loved Hunter Lane Jr. and everything he stood for. He will be missed, but not forgotten.
      <p> </p>
    </div>
  </div>
  <p class="darkertext"><br />
    <strong><img src="/images/flame.jpg" alt="Pitch graphic" width="15" height="49" />Get this hot stuff now:</strong>&nbsp;Beat the heat with this Summer Sizzler Sale. <a target="_blank" href="http://www.gochampion.net/images/12ChampionSummerSizzler.jpg" _mce_href="http://www.gochampion.net/images/12ChampionSummerSizzler.jpg">Click Here.</a></p>
  <div><div>
  <p>&nbsp;</p></div></div>
<p class="darkertext">&nbsp;</p></div>
<br/>
				<img src="images/pagefooter.jpg" width="490" height="20" alt="Page layout footer"/> 
				
				
							
				
  			</div> 
			
			
				

			<div id="position_rightcol-sub">
				
				
				
				
				<p class="darkertext">
				From the desk of <a class="link_noline" href="staffbios.php#mike"><strong>Mike Bowen</strong></a>.<br/><br/>
				<img class="align-right" src="images/bios_mike-mini.jpg" width="100" height="125" alt="Mike"/>
				Mike Bowen is CEO &amp; President of
Champion Awards &amp; Apparel Inc. Mike has assisted businesses grow through sensible advice about corporate apparel, awards and promotional products for over 30 years.
				</p>
    </div>