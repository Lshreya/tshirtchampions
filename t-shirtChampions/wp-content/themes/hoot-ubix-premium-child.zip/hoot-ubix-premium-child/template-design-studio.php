<?php
/*
Template Name: Design Studio
 */

get_header();
the_post();
 ?>
    <html>
        <head>
        </head>
        <body>
        <div>
            <script type="text/javascript" language="javascript" src="https://stores.inksoft.com/designer/html5/common/js/launcher.js"></script>
            <div align="center" id="embeddedDesigner"></div>
            <script type="text/javascript" language="javascript">
                var flashvars = {
            DesignerLocation: "https://images.inksoft.com/designer/html5",
            EnforceBoundaries: "1",
            Background: "",
            VectorOnly: false,
            DigitalPrint: true,
            ScreenPrint: true,
            Embroidery: false,
            MaxScreenPrintColors: "6",
            RoundPrices: false,
            StoreID: "38180",
            PublisherID: "6632",
            SessionID: "",
            SessionToken: "",
            CartRetailItemID: "",
            UserID: "",
            UserName: "",
            UserEmail: "",
            DesignID: "",
            DefaultProductID: "1000033",
            DefaultProductStyleID: "1000886",
            ProductID: "1000033",
            ProductStyleID: "1000886",
            ProductCategoryID: "1000033",
            ClipArtGalleryID: "",
            DisableAddToCart: false,
            DisableUploadImage: false,
            DisableClipArt: false,
            DisableUserArt: false,
            DisableProducts: false,
            DisableDesigns: false,
            DisableDistress: false,
            DisableResolutionMeter: false,
            DisableUploadVectorArt: false,
            DisableUploadRasterArt: false,
            StartPage: "",
            StartPageCategoryID: "",
            StartPageHTML: "",
            StartBanner: "",
            OrderID: "",
            CartID: "",
            ArtID: "",
            FontID: "",
            Domain: "stores.inksoft.com",
            SSLEnabled: true,
            SSLDomain: "stores.inksoft.com",
            StoreURI: "TSC",
            Admin: "",
            NextURL: "",
            CartURL: "https://stores.inksoft.com/TSC/Cart",
            OrderSummary: true,
            VideoLink: "http://www.youtube.com/watch?v=EfXICdRwt4E",
            Phone: "855-350-4830",
            WelcomeScreen: "",
            ContactUsLink: "/TSC/Stores/Contact",
            WelcomeVideo: "",
            GreetBoxSetting: "",
            HelpVideoOverview: "",
            AutoZoom: true,
            EnableNameNumbers: false,
            AddThisPublisherId: "xa-4fccb0966fef0ba7",
            EnableCartPricing: true,
            EnableCartCheckout: true,
            EnableCartBilling: false,
            EnableCartShipping: true,
            PaymentDisabled: false,
            PaymentRequired: true,
            BillingAddressRequired: true,
            PasswordLength: "4",
            DefaultCountryCode: "US",
            CurrencyCode: "USD",
            CurrencySymbol: "$",
            HideProductPricing: true,
            PB: true,
            HideClipArtNames: true,
            HideDesignNames: true,
            ThemeName: "flat",
            FullScreen: false,
            Version: "3.11.0.0",
            BackgroundColor: "",
            StoreLogo: "//stores.inksoft.com/images/publishers/6632/stores/TSC/img/logo.png",
            StoreName: "T-Shirt Champions",
            StoreEmail: "contact@tshirtchampions.com",
            EnableEZD: false,
            EmbedType: "iframe"};
                launchDesigner('HTML5DS', flashvars, document.getElementById("embeddedDesigner"));
            </script>
</div>
</body>
</html>


<?php get_footer(); // Loads the footer.php template. ?>
?>