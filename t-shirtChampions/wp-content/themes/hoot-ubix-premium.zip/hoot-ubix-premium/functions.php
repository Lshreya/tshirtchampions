<?php
/**
 *                  _   _             _   
 *  __      ___ __ | | | | ___   ___ | |_ 
 *  \ \ /\ / / '_ \| |_| |/ _ \ / _ \| __|
 *   \ V  V /| |_) |  _  | (_) | (_) | |_ 
 *    \_/\_/ | .__/|_| |_|\___/ \___/ \__|
 *           |_|                          
 * -------------------------------------------
 * -- HOOT THEME BUILT ON HYBRID FRAMEWORK ---
 * -------------------------------------------
 * - incorporate code from Hybrid Base Theme -
 * -- Underscores Theme, Customizer Library --
 * -- (see readme file for copyright info.) --
 * -------------------------------------------
 *
 * :: Theme's main functions file :::::::::::::::::::::::::::::::::::::::::::::
 * :: Initialize and setup the theme framework, helper functions and objects ::
 *
 * To modify this theme, its a good idea to create a child theme. This way you can easily update
 * the main theme without loosing your changes. To know more about how to create child themes 
 * @see http://codex.wordpress.org/Theme_Development
 * @see http://codex.wordpress.org/Child_Themes
 *
 * Hooks, Actions and Filters are used throughout this theme. You should be able to do most of your
 * customizations without touching the main code. For more information on hooks, actions, and filters
 * @see http://codex.wordpress.org/Plugin_API
 *
 * @package    Hoot
 * @subpackage Hoot Ubix
 */

/**
 * Uncomment the line below to load unminified CSS and JS, and add other developer data to code.
 * - You can set this to true (default) for loading unminified files (useful for development/debugging)
 * - Or set it to false for loading minified files (for production i.e. live site)
 * 
 * NOTE: If you uncomment this line, HYBRIDEXTEND_DEBUG value will override any option for minifying
 * files (if available) set via the theme options (customizer) in WordPress Admin
 */
// define( 'HYBRIDEXTEND_DEBUG', true );

/* Get the template directory and make sure it has a trailing slash. */
$hoot_base_dir = trailingslashit( get_template_directory() );

/* Load the Core framework and theme files */
require_once( $hoot_base_dir . 'hybrid/hybrid.php' );
require_once( $hoot_base_dir . 'hybrid/extend/extend.php' );
require_once( $hoot_base_dir . 'include/hoot-theme.php' );

/* Framework and Theme Setup files loaded */
do_action( 'hoot_loaded' );

/* Launch the Hybrid framework. */
new Hybrid();
$hybridextend = new Hybrid_Extend();

/* Framework Setup complete */
do_action( 'hybrid_after_setup' );

/* Launch the Theme */
$hoot_theme = new Hoot_Theme();

/* Hoot Theme Setup complete */
do_action( 'hoot_theme_after_setup' );


// Our custom post type function
function create_posttype() {
    register_post_type( 'tsc_product',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Products' ),
                'singular_name' => __( 'Product' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'products'),
            'menu_icon' => 'dashicons-cart',
            'supports' => array( 'title', 'editor', 'thumbnail' )
        )
    );
    register_post_type( 'tsc_garment',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Garments' ),
                'singular_name' => __( 'Garment' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'garments'),
            'menu_icon' => 'dashicons-cart',
            'supports' => array( 'title', 'editor', 'thumbnail')
        )
    );
 register_post_type( 'tsc_testimonials',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Testimonials' ),
                'singular_name' => __( 'Testimonial' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'testimonials'),
            'menu_icon' => 'dashicons-admin-users',
            'supports' => array( 'title', 'editor', 'thumbnail' )
        )
    );
 register_post_type( 'tsc_team',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Team' ),
                'singular_name' => __( 'Team' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'staff'),
            'menu_icon' => 'dashicons-admin-multisite',
            'supports' => array( 'title', 'editor', 'thumbnail', 'page-attributes')
        )
    );
 register_post_type( 'tsc_champion',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Champions' ),
                'singular_name' => __( 'Champion' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'champion'),
            'menu_icon' => 'dashicons-awards',
            'supports' => array( 'title', 'editor', 'thumbnail' )
        )
    );

}

// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );
add_action( 'init', 'create_product_tax' );

// taxonomy
function create_product_tax() {
  register_taxonomy(
    'tsc_product_category',
    'tsc_product',
    array(
      'label' => __( 'Product Category' ),
      'rewrite' => array( 'slug' => 'product-category' ),
      'hierarchical' => true,
    )
  );

  register_taxonomy(
    'tsc_garment_category',
    'tsc_garment',
    array(
      'label' => __( 'Garment Category' ),
      'rewrite' => array( 'slug' => 'garment-category' ),
      'hierarchical' => true,
    )
  );
}